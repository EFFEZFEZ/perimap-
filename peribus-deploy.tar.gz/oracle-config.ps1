﻿# Configuration Oracle Cloud - NE PAS COMMIT (gitignored)

$ORACLE_IP = "79.72.24.141"
$ORACLE_USER = "ubuntu"
$SSH_KEY_PATH = "C:\Users\chadi\Downloads\ssh-key-2026-01-09.key"
$REMOTE_PATH = "~/perimap-"

function Connect-Oracle {
    Write-Host "Connexion SSH a Oracle Cloud..." -ForegroundColor Cyan
    ssh -i $SSH_KEY_PATH $ORACLE_USER@$ORACLE_IP
}

function Deploy-Oracle {
    Write-Host "Deploiement sur Oracle Cloud..." -ForegroundColor Cyan
    ssh -i $SSH_KEY_PATH $ORACLE_USER@$ORACLE_IP "cd $REMOTE_PATH && git pull && cd server && npm install --production && pm2 restart perimap-server || pm2 start index.js --name perimap-server && pm2 save"
}

function Oracle-Logs {
    Write-Host "Logs du serveur Oracle..." -ForegroundColor Cyan
    ssh -i $SSH_KEY_PATH $ORACLE_USER@$ORACLE_IP "pm2 logs perimap-server --lines 100"
}

function Oracle-Status {
    Write-Host "Status du serveur Oracle..." -ForegroundColor Cyan
    ssh -i $SSH_KEY_PATH $ORACLE_USER@$ORACLE_IP "pm2 list; curl -s http://localhost:3000/api/routes/health"
}

function Oracle-Restart {
    Write-Host "Redemarrage du serveur Oracle..." -ForegroundColor Cyan
    ssh -i $SSH_KEY_PATH $ORACLE_USER@$ORACLE_IP "pm2 restart perimap-server"
}

Write-Host ""
Write-Host "Configuration Oracle Cloud chargee" -ForegroundColor Green
Write-Host "IP Oracle: $ORACLE_IP" -ForegroundColor Cyan
Write-Host "Chemin: $REMOTE_PATH" -ForegroundColor Cyan
Write-Host ""
Write-Host "Commandes disponibles:" -ForegroundColor Yellow
Write-Host "  Connect-Oracle    - Se connecter en SSH"
Write-Host "  Deploy-Oracle     - Deployer la derniere version"
Write-Host "  Oracle-Logs       - Voir les logs"
Write-Host "  Oracle-Status     - Verifier le status"
Write-Host "  Oracle-Restart    - Redemarrer le serveur"
Write-Host ""
